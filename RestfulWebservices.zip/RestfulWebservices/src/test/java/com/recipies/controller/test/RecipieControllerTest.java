package com.recipies.controller.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.recipies.controllers.RecipieController;
import com.recipies.entity.Recipie;
import com.recipies.service.RecipieService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SpringBootTest
class RecipieControllerTest {

    @InjectMocks
    private RecipieController recipieController;

    @Mock
    private RecipieService recipieService;

    @Test
    void testAddProduct() {
        Recipie newRecipe = new Recipie(); // Replace with your actual Recipie model

        // Mocking the service response
        Mockito.when(recipieService.addProduct(newRecipe)).thenReturn(newRecipe);
        Mockito.when(recipieService.getAllProducts()).thenReturn(new ArrayList<>()); // Replace with your list of Recipie objects

        List<Recipie> result = recipieController.addProduct(newRecipe);

        assertNotNull(result);
        // Add more assertions as needed to validate the result.
    }

    @Test
    void testGetAll() {
        List<Recipie> recipieList = new ArrayList<>(); // Replace with a list of Recipie objects

        // Mocking the service response
        Mockito.when(recipieService.getAllProducts()).thenReturn(recipieList);

        List<Recipie> result = recipieController.getAll();

        assertEquals(recipieList, result);
    }

    @Test
    void testGetProductByName() {
        String recipeName = "Example Recipe Name"; // Replace with an actual recipe name
        Recipie recipe = new Recipie(); // Replace with your actual Recipie model

        // Mocking the service response
        Mockito.when(recipieService.Getproductbyname(recipeName)).thenReturn(recipe);

        Recipie result = recipieController.getProductByName(recipeName);

        assertNotNull(result);
        // Add more assertions as needed to validate the result.
    }

    // Write similar test methods for the remaining controller methods
}
