package com.recipies.controller.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.recipies.controllers.AdminController;
import com.recipies.entity.Admin;
import com.recipies.service.AdminService;

@SpringBootTest
class AdminControllerTest {

    @InjectMocks
    private AdminController adminController;

    @Mock
    private AdminService adminService;

 
    @Test
    void testPrintAdmin() {
        List<Admin> adminList = new ArrayList<>(); // Replace with a list of Admin objects

        // Mocking the service response
        Mockito.when(adminService.getallAdmin()).thenReturn(adminList);

        List<Admin> result = adminController.printAdmin();

        assertEquals(adminList, result); // Assert that the returned list matches the expected list
    }
}
