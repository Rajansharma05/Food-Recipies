package com.recipies.controller.test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.recipies.controllers.UserController;
import com.recipies.entity.User;
import com.recipies.service.UserService;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
class UserControllerTest {

    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userService;

    @Test
    void testFindByEmail() {
        User user = new User(4, "rajans", "rajans@gmail.com","313131", 0); // Replace with your actual User model

        // Mocking the service response
        Mockito.when(userService.getUserByEmail(user.getEmail())).thenReturn(user);

        ResponseEntity<?> result = userController.findByEmail(user);

        System.out.println("Result: " + result); // Add this line for debugging

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        // Add more assertions or debugging as needed to validate the result.
    }

    @Test
    void testGetById() {
        int Id = 4; // Replace with an actual user ID
        User user = new User(); // Replace with your actual User model

        // Mocking the service response
        Mockito.when(userService.findbyid(Id)).thenReturn(user);

        User result = userController.getbyid(Id);

        assertNotNull(result);
        // Add more assertions as needed to validate the result.
    }

    @Test
    void testUserDetails() {
        List<User> userList = new ArrayList<>(); // Replace with a list of User objects

        // Mocking the service response
        Mockito.when(userService.listAll()).thenReturn(userList);

        List<User> result = userController.UserDetails();

        assertEquals(userList, result);
    }

    // Write similar test methods for the remaining controller methods
}
