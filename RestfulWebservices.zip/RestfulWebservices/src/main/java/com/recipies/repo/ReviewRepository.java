package com.recipies.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.recipies.entity.Review;

@Repository
public interface ReviewRepository extends JpaRepository<Review, String>{
	

}