package com.recipies.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.recipies.entity.User;
import com.recipies.service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> findByEmail(@RequestBody User user) {
        User obj = userService.getUserByEmail(user.getEmail());
        if(obj != null && user.getEmail().equals(obj.getEmail()) && user.getPassword().equals(obj.getPassword())) {
        	return ResponseEntity.ok(obj);
        }
        return (ResponseEntity<?>) ResponseEntity.internalServerError();
    }

    @GetMapping("/{id}")
    public User getbyid(@PathVariable int id)
    {
    return userService.findbyid(id);
    }
    @GetMapping("/list")
    public List<User> UserDetails() {
        return userService.listAll();

    }

  @PutMapping("/update/{id}")
    public User updateById(@PathVariable int id,@RequestBody User user) {
        User dbUser = userService.FindByid(id);
        System.out.println(id);
        if (dbUser != null) {
            dbUser.setEmail(user.getEmail());
            dbUser.setName(user.getName());
            dbUser.setPhone(user.getPhone());
            dbUser.setPassword(user.getPassword());
            return userService.save(dbUser);
        }
        return user;
    }

    @PostMapping("/register")
    public User Register(@RequestBody User user) {
        userService.save(user);
        return user;
    }

//    @PostMapping("/changepassword")
//    public void changePassword(@RequestBody User user) {
//        User dbUser = userService.getUserByEmail(user.getEmail());
//        if (dbUser != null & user.getPassword() != null) {
//            dbUser.setPassword(user.getPassword());
//        }
//    }
    @PutMapping("/changepassword/{id}")
	public String changepassword(@PathVariable int id ,@RequestBody String  pass) {
		return userService.changepassword(id,pass);
	}
}